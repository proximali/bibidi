#pragma once

#define HTTP_SERVER "109.104.151.112"
#define HTTP_PORT 80

#define TFTP_SERVER "109.104.151.112"